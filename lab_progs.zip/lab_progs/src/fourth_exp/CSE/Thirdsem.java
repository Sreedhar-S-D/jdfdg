package fourth_exp.CSE;

import org.w3c.dom.ls.LSOutput;

public class Thirdsem {
    void Welocomemsg()
    {
        System.out.println("Welcome to CSE dept- Young Budding Engineers");
    }
}
