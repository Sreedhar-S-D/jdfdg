package second_exp;


public class employee {
    String EmpID,Name;
    address addr;

    public employee(String empID, String name, address addr) {
        EmpID = empID;
        Name = name;
        this.addr = addr;
    }
}
