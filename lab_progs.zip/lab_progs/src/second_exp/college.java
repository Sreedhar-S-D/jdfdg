package second_exp;

public class college {
    String Name;
    address addr;

    public college(String name, address addr) {
        Name = name;
        this.addr = addr;
    }
}
