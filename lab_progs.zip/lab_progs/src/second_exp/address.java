package second_exp;

public class address {
    int Streetnumber;
    String city,State,Country;

    public address(int streetnumber, String city, String state, String country) {
        Streetnumber = streetnumber;
        this.city = city;
        State = state;
        Country = country;
    }
}
