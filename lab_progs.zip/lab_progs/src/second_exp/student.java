package second_exp;

public class student {
    String USN;
    String Name;
    address addr;

    public student()
    {

    }

    public student(String USN, String name, address addr) {
        this.USN = USN;
        Name = name;
        this.addr = addr;
    }

}